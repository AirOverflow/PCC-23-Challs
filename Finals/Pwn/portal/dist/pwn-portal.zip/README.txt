Ignore that `runner` binary. Not part of the challenge.

---
